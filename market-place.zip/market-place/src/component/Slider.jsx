import Slider from "react-slick";
import pic1 from '../assets/item-pics/pic.png';
import pic2 from '../assets/item-pics/pic-1.png';
import pic3 from '../assets/item-pics/pic-2.png';
import pic4 from '../assets/item-pics/pic-3.png';
import ProductCard from "./ProductCard";

const product = [
    { img: pic1, price: 42.99, productname: "New Laptop RGB Mode New Laptop RGB Mode", seller: "John Doe", discount: 10},
    { img: pic2, price: 100.00, productname: "Bright Red Shoe Nike", seller: "Grecon Coast West" },
    { img: pic3, price: 15.50, productname: "Magic Lotion Unicorn", seller: "JOHNSON" },
    { img: pic4, price: 85.00, productname: "White Clothing", seller: "Succulent Oasis" },
    { img: pic1, price: 42.99, productname: "New Laptop RGB Mode", seller: "John Doe" },
    { img: pic2, price: 100.00, productname: "Bright Red Shoe Nike", seller: "Grecon Coast West" },
    { img: pic3, price: 15.50, productname: "Magic Lotion Unicorn", seller: "JOHNSON" },
    { img: pic4, price: 85.00, productname: "White Clothing", seller: "Succulent Oasis" }
]

const settings = {
    dots: false,
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    speed: 2000,
    autoplaySpeed: 2000,
    cssEase: "ease",
    variableHeight: true,
    responsive: [
        {
            breakpoint: 500, 
            settings: {
              slidesToShow: 2,
            }
        },
        {
            breakpoint: 700, 
            settings: {
              slidesToShow: 3,
            }
        },
    ]
};

const SliderProduct = () => {
    return (
        <div className="slider">
            <Slider {...settings} >
            {
                product.map((item, index) => {
                    return <ProductCard key={index} item={item}></ProductCard>
                })
            }
            </Slider>
        </div>
    )
}

export default SliderProduct;