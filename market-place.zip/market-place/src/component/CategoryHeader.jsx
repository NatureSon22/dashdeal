import { MenuItem, Select } from "@mui/material";
import { useEffect, useState } from "react";
import fb from "../assets/fb.png";
import insta from "../assets/insta.png";
import tiktok from "../assets/tiktok.png";
import twitter from "../assets/twitter.png";

const socials = [
    { icon: fb, label: "Like our Facebook Page" },
    { icon: insta, label: "Follow us on Instagram" },
    { icon: twitter, label: "Search us on X!" },
    { icon: tiktok, label: "See us on TikTok" }
];


const CategoryHeader = () => {
    const [categories, setCategories] = useState([]);
    const [category, setCategory] = useState(""); 
    const [socialCategory, setSocialCategory] = useState("");

    const handleChange = (event) => {
        setCategory(event.target.value);
    }

    const handleSetSocialCategory = (event) => {
        setSocialCategory(event.target.value);
    }

    useEffect(() => {
        const getCategories = async() => {
            const res = await fetch("http://localhost:3000/backend/getcategories.php", {
                method: "GET"
            });
            const data = await res.json();
            setCategories(data);
        }

        getCategories();
    }, [])

    return (
        <div className="category-header" >
            <Select
                className="category-label"
                onChange={handleChange}
                value={category}
                sx={{ fontFamily: 'Poppins, sans-serif' }}
                displayEmpty
            >
                <MenuItem disabled value="">
                    Shop By Category
                </MenuItem>
                {categories.map((item, index) => (
                    <MenuItem key={index} value={item}>
                        {item.categoryname}
                    </MenuItem>
                ))}
            </Select>
            
            <Select
                className="category-label"
                onChange={handleSetSocialCategory}
                value={socialCategory}
                sx={{ fontFamily: 'Poppins, sans-serif' }}
                displayEmpty
            >
                <MenuItem disabled value="">
                    Communicate with us!
                </MenuItem>
                {socials.map((item, index) => (
                    <MenuItem key={index} value={item} className="label" >
                        <img src={item.icon} alt="" />
                        <p>{item.label}</p>
                    </MenuItem>
                ))}
            </Select>
        </div>
    )

}

export default CategoryHeader;
