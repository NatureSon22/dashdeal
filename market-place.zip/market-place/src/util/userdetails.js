import { create } from "zustand";

export const userDetails = create((set) => ({
    details: [],
    setDetails: () => set(async() => {
    })
})); 