<?php   
    include("db-config.php");
    
    $formdata = json_decode(file_get_contents("php://input"));
    $sql = "DELETE FROM cart_tb WHERE product_id = (?)";
    $stmt = $connect->prepare($sql);
    $stmt->execute([$formdata->productId]);

    echo "Item successfully removed to cart";
?>